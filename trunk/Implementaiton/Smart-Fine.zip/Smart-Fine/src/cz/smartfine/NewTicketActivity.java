package cz.smartfine;

import java.util.Date;

import model.Ticket;
import cz.smartfine.R;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

/**
 * @author Martin Stajner
 * 
 */
public class NewTicketActivity extends Activity {
	
	private MyApp app;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.newticket);
		this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
		
		app = (MyApp) this.getApplication();
	}

	public void saveTicket(View target) {
		Ticket ticket = createTicket();
		String error = checkTicket(ticket);
		if ( error != null) {
			Toast.makeText(getApplicationContext(),	error, Toast.LENGTH_LONG).show();			
		} else {
			Toast.makeText(getApplicationContext(), R.string.Parkovaci_listek_ulozen, Toast.LENGTH_LONG).show();
			app.getLocals().add(ticket);
			this.setResult(RESULT_OK);
			finish();
		}
	}

	public Ticket createTicket() {
		Ticket ticket = new Ticket();

		ticket.setDate(new Date());
		ticket.setBadgeNumber(3403234);

		ticket.setSpz(((EditText) findViewById(R.id.spz)).getText().toString());
		ticket.setMpz(((EditText) findViewById(R.id.mpz)).getText().toString());
		ticket.setSpzColor(((EditText) findViewById(R.id.spzColor)).getText().toString());
		ticket.setVehicleType(((EditText) findViewById(R.id.vehicleType)).getText().toString());
		ticket.setVehicleBrand(((EditText) findViewById(R.id.vehicleBrand)).getText().toString());
		ticket.setCity(((EditText) findViewById(R.id.city)).getText().toString());
		ticket.setStreet(((EditText) findViewById(R.id.street)).getText().toString());
		if ((((EditText)findViewById(R.id.number)).getText().toString()).equals("")) {
			ticket.setNumber(0);
		} else {
			ticket.setNumber(Integer.valueOf(((EditText)findViewById(R.id.number)).getText().toString()));
		}
		ticket.setLocation(((EditText) findViewById(R.id.location)).getText().toString());
		ticket.setDescriptionDZ(((EditText) findViewById(R.id.descriptionDZ)).getText().toString());
		ticket.setTow(((CheckBox) findViewById(R.id.tow)).isChecked());
		ticket.setMoveableDZ(((CheckBox) findViewById(R.id.moveableDZ)).isChecked());
		ticket.setEventDescription(((EditText) findViewById(R.id.eventDescription)).getText().toString());

		return ticket;
	}

	public String checkTicket(Ticket ticket) {
		String error = "";
		if (ticket.getSpz().equals("")) {
			error += "Mus�te vyplnit SPZ.\n";
		}
		if (ticket.getMpz().equals("")) {
			error += "Mus�te vyplnit MPZ.\n";
		}
		if (ticket.getVehicleType().equals("")) {
			error += "Mus�te vyplnit druh vozidla.\n";
		}
		if (ticket.getVehicleBrand().equals("")) {
			error += "Mus�te vyplnit tov�rn� zna�ku vozidla.\n";
		}
		if (ticket.getCity().equals("")) {
			error += "Mus�te vyplnit m�sto.\n";
		}
		if (ticket.getStreet().equals("")) {
			error += "Mus�te vyplnit ulici.\n";
		}
		if (ticket.getNumber() == 0) {
			error += "Mus�te vyplnit ��slo ulice.";
		}

		if (error.length() != 0) {
			return error;
		} else {
			return null;
		}
	}
}