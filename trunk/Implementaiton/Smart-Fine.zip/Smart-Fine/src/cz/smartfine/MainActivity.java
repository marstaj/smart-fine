package cz.smartfine;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends Activity {

	/**
	 * Instance aplikace
	 */
	private MyApp app;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
    	app = (MyApp) this.getApplication();
    }
        
    public void newTicketClick(View target) {
    	this.startActivityForResult(new Intent(this, NewTicketActivity.class), 1);
	}
    
    
    @Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
            	Toast.makeText(getApplicationContext(), app.getLocals().get(0).getSpz(), Toast.LENGTH_LONG).show();
            }
        }
	}

	protected void onActivityResult(int requestCode, int resultCode) {
        
    }
    
    public void listClick(View target) {
    	this.startActivity(new Intent(this, LocalListActivity.class));
	}

}