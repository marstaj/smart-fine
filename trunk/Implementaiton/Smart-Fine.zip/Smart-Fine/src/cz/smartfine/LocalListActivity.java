package cz.smartfine;

import cz.smartfine.R;
import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

public class LocalListActivity extends Activity {
	/** Called when the activity is first created. */
	
	private MyApp app;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.locallist);
		
		app = (MyApp) this.getApplication();

		ListView lv = (ListView) this.findViewById(R.id.listView1);
		lv.setTextFilterEnabled(true);
		//lv.setAdapter(new ArrayAdapter<Ticket>(this, R.layout.listitem, getResources().getStringArray(R.array.zaznamy)));
		lv.setAdapter(new TicketAdapter(this, R.layout.listitem, app.getLocals()));
	}
}