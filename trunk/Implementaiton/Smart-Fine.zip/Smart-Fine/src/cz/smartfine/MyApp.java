package cz.smartfine;

import java.util.ArrayList;

import model.Ticket;
import dao.TicketDao;
import android.app.Application;

public class MyApp extends Application {

	ArrayList<Ticket> locals;
	TicketDao dao;

	
	@Override
	public void onCreate() {
		super.onCreate();
		this.locals = new ArrayList<Ticket>();
		this.dao = new TicketDao(this.getApplicationContext());
	}

	public ArrayList<Ticket> getLocals() {
		return locals;
	}

	public void setLocals(ArrayList<Ticket> locals) {
		this.locals = locals;
	}

	public TicketDao getDao() {
		return dao;
	}

	public void setDao(TicketDao dao) {
		this.dao = dao;
	}
}
