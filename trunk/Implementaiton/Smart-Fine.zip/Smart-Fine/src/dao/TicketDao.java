package dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.util.ArrayList;

import cz.smartfine.R;

import android.content.Context;
import android.widget.Toast;

import model.Ticket;

public class TicketDao {

	Context context;

	public TicketDao(Context context) {
		super();
		this.context = context;
	}

	public boolean saveTicket(ArrayList<Ticket> list) {

		try {
			FileOutputStream fos = context.openFileOutput("data", Context.MODE_PRIVATE);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(list);
			fos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			Toast.makeText(context, "FileNotFoundException output", Toast.LENGTH_LONG).show();
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Toast.makeText(context, "IOException output", Toast.LENGTH_LONG).show();
			e.printStackTrace();
		}
		return true;
	}
	
	public ArrayList<Ticket> loadTickets() {
		
		try {
			FileInputStream fis = context.openFileInput("data");
			ObjectInputStream ois = new ObjectInputStream(fis);
			ArrayList<Ticket> ticket = (ArrayList<Ticket>)ois.readObject();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			Toast.makeText(context, "FileNotFoundException input", Toast.LENGTH_LONG).show();
			e.printStackTrace();
		} catch (StreamCorruptedException e) {
			// TODO Auto-generated catch block
			Toast.makeText(context, "Stream corupted input", Toast.LENGTH_LONG).show();
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Toast.makeText(context, "IOException input", Toast.LENGTH_LONG).show();
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			Toast.makeText(context, "ClassNotFoundException input", Toast.LENGTH_LONG).show();
			e.printStackTrace();
		}
	}
}