package model;

public class Law {

	/**
	 * Sb�rka
	 */
	private int collection;
	/**
	 * Odstavec
	 */
	private int description;
	/**
	 * ��slo z�kona
	 */
	private int lawNumber;
	/**
	 * P�smeno
	 */
	private int letter;
	/**
	 * Odstavec z�kona (Nikoliv �)
	 */
	private int paragraph;
	/**
	 * Parafgraf z�kona, �l�nek z�kona (�)
	 */
	private int ruleOfLaw;

	public Law(){

	}

	public void finalize() throws Throwable {

	}

	/**
	 * @return the collection
	 */
	public int getCollection() {
		return collection;
	}

	/**
	 * @param collection the collection to set
	 */
	public void setCollection(int collection) {
		this.collection = collection;
	}

	/**
	 * @return the description
	 */
	public int getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(int description) {
		this.description = description;
	}

	/**
	 * @return the lawNumber
	 */
	public int getLawNumber() {
		return lawNumber;
	}

	/**
	 * @param lawNumber the lawNumber to set
	 */
	public void setLawNumber(int lawNumber) {
		this.lawNumber = lawNumber;
	}

	/**
	 * @return the letter
	 */
	public int getLetter() {
		return letter;
	}

	/**
	 * @param letter the letter to set
	 */
	public void setLetter(int letter) {
		this.letter = letter;
	}

	/**
	 * @return the paragraph
	 */
	public int getParagraph() {
		return paragraph;
	}

	/**
	 * @param paragraph the paragraph to set
	 */
	public void setParagraph(int paragraph) {
		this.paragraph = paragraph;
	}

	/**
	 * @return the ruleOfLaw
	 */
	public int getRuleOfLaw() {
		return ruleOfLaw;
	}

	/**
	 * @param ruleOfLaw the ruleOfLaw to set
	 */
	public void setRuleOfLaw(int ruleOfLaw) {
		this.ruleOfLaw = ruleOfLaw;
	}

}