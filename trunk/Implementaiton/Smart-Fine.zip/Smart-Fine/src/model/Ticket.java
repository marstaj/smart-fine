package model;

import java.util.Date;

public class Ticket {

	/**
	 * Slu�ebn� ��slo - ��slo odznaku policisty
	 */
	private int badgeNumber;
	/**
	 * M�sto
	 */
	private String city;
	/**
	 * Datum a �as
	 */
	private Date date;
	/**
	 * Popis DZ
	 */
	private String descriptionDZ;
	/**
	 * Popis ud�losti
	 */
	private String eventDescription;
	/**
	 * M�sto ud�losti (nap�.: na chodn�ku)
	 */
	private String location;
	/**
	 * Zda je pohybliv� DZ
	 */
	private boolean moveableDZ;
	/**
	 * Mezin�rodn� pozn�vac� zna�ka
	 */
	private String mpz;
	/**
	 * ��slo ulice
	 */
	private int number;
	/**
	 * Fotografie ud�losti
	 */
	private String[] photos;
	/**
	 * St�tn� pozn�vac� zna�ka
	 */
	private String spz;
	/**
	 * Barva SPZ
	 */
	private String spzColor;
	/**
	 * Ulice
	 */
	private String street;
	/**
	 * Zda odtah vozidla
	 */
	private boolean tow;
	/**
	 * Zna�ka automobilu
	 */
	private String vehicleBrand;
	/**
	 * Typ automobilu
	 */
	private String vehicleType;
	/**
	 * Z�kon popisuj�c� p�estupek
	 */
	private Law law;

	public Ticket(){

	}

	public void finalize() throws Throwable {

	}

	/**
	 * @return the badgeNumber
	 */
	public int getBadgeNumber() {
		return badgeNumber;
	}

	/**
	 * @param badgeNumber the badgeNumber to set
	 */
	public void setBadgeNumber(int badgeNumber) {
		this.badgeNumber = badgeNumber;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * @return the descriptionDZ
	 */
	public String getDescriptionDZ() {
		return descriptionDZ;
	}

	/**
	 * @param descriptionDZ the descriptionDZ to set
	 */
	public void setDescriptionDZ(String descriptionDZ) {
		this.descriptionDZ = descriptionDZ;
	}

	/**
	 * @return the eventDescription
	 */
	public String getEventDescription() {
		return eventDescription;
	}

	/**
	 * @param eventDescription the eventDescription to set
	 */
	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}

	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * @return the moveableDZ
	 */
	public boolean isMoveableDZ() {
		return moveableDZ;
	}

	/**
	 * @param moveableDZ the moveableDZ to set
	 */
	public void setMoveableDZ(boolean moveableDZ) {
		this.moveableDZ = moveableDZ;
	}

	/**
	 * @return the mpz
	 */
	public String getMpz() {
		return mpz;
	}

	/**
	 * @param mpz the mpz to set
	 */
	public void setMpz(String mpz) {
		this.mpz = mpz;
	}

	/**
	 * @return the number
	 */
	public int getNumber() {
		return number;
	}

	/**
	 * @param number the number to set
	 */
	public void setNumber(int number) {
		this.number = number;
	}

	/**
	 * @return the photos
	 */
	public String[] getPhotos() {
		return photos;
	}

	/**
	 * @param photos the photos to set
	 */
	public void setPhotos(String[] photos) {
		this.photos = photos;
	}

	/**
	 * @return the spz
	 */
	public String getSpz() {
		return spz;
	}

	/**
	 * @param spz the spz to set
	 */
	public void setSpz(String spz) {
		this.spz = spz;
	}

	/**
	 * @return the spzColor
	 */
	public String getSpzColor() {
		return spzColor;
	}

	/**
	 * @param spzColor the spzColor to set
	 */
	public void setSpzColor(String spzColor) {
		this.spzColor = spzColor;
	}

	/**
	 * @return the street
	 */
	public String getStreet() {
		return street;
	}

	/**
	 * @param street the street to set
	 */
	public void setStreet(String street) {
		this.street = street;
	}

	/**
	 * @return the tow
	 */
	public boolean isTow() {
		return tow;
	}

	/**
	 * @param tow the tow to set
	 */
	public void setTow(boolean tow) {
		this.tow = tow;
	}

	/**
	 * @return the vehicleBrand
	 */
	public String getVehicleBrand() {
		return vehicleBrand;
	}

	/**
	 * @param vehicleBrand the vehicleBrand to set
	 */
	public void setVehicleBrand(String vehicleBrand) {
		this.vehicleBrand = vehicleBrand;
	}

	/**
	 * @return the vehicleType
	 */
	public String getVehicleType() {
		return vehicleType;
	}

	/**
	 * @param vehicleType the vehicleType to set
	 */
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	/**
	 * @return the law
	 */
	public Law getLaw() {
		return law;
	}

	/**
	 * @param law the law to set
	 */
	public void setLaw(Law law) {
		this.law = law;
	}

	
}